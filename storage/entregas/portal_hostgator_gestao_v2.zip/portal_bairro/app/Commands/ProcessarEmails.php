<?php
namespace App\Commands;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\PortalRepository;
use PDO;
final class ProcessarEmails extends BaseCommand
{
 protected $group='Portal';protected $name='portal:emails';protected $description='Processa até 20 mensagens pela configuração SMTP privada.';
 public function run(array $params){
  if(!env('email.SMTPHost')||!env('email.fromEmail')){CLI::error('SMTP não configurado. Nenhuma mensagem enviada.');return EXIT_ERROR;}
  $repo=new PortalRepository();$enviados=0;$falhas=0;
  for($i=0;$i<20;$i++){
   $m=$repo->transaction(function()use($repo){
    $m=$repo->run("SELECT * FROM fila_emails WHERE situacao='pendente' AND tentativas<5 AND (proxima_tentativa_em IS NULL OR proxima_tentativa_em<=?) AND (bloqueado_em IS NULL OR bloqueado_em<?) ORDER BY id LIMIT 1".($repo->mysql()?' FOR UPDATE':''),[gmdate('Y-m-d H:i:s'),gmdate('Y-m-d H:i:s',time()-600)])->fetch(PDO::FETCH_ASSOC);
    if(!$m)return null;$repo->run('UPDATE fila_emails SET bloqueado_em=?,tentativas=tentativas+1 WHERE id=?',[gmdate('Y-m-d H:i:s'),$m['id']]);return $m;
   });if(!$m)break;
   $mail=\Config\Services::email(null,false);
   try{
    $mail->initialize(['protocol'=>'smtp','SMTPHost'=>env('email.SMTPHost'),'SMTPUser'=>env('email.SMTPUser',''),'SMTPPass'=>env('email.SMTPPass',''),'SMTPPort'=>(int)env('email.SMTPPort',587),'SMTPCrypto'=>env('email.SMTPCrypto','tls'),'SMTPTimeout'=>15,'mailType'=>'text','charset'=>'UTF-8','newline'=>"\r\n",'CRLF'=>"\r\n"]);
    $mail->setFrom(env('email.fromEmail'),env('email.fromName','Portal do Bairro'));$mail->setTo($m['destinatario']);$mail->setSubject($m['assunto']);$mail->setMessage($m['mensagem']);
    if(!$mail->send(false))throw new \RuntimeException('Falha no envio SMTP.');
    $repo->run("UPDATE fila_emails SET situacao='enviado',enviado_em=?,mensagem=NULL,bloqueado_em=NULL,ultimo_erro=NULL WHERE id=?",[gmdate('Y-m-d H:i:s'),$m['id']]);$enviados++;
   }catch(\Throwable $e){$falhas++;$repo->run('UPDATE fila_emails SET bloqueado_em=NULL,proxima_tentativa_em=?,ultimo_erro=? WHERE id=?',[gmdate('Y-m-d H:i:s',time()+300),'Falha no envio; confira configuração SMTP.',$m['id']]);CLI::error('Mensagem '.$m['id'].' não enviada; nova tentativa agendada.');}
  }
  CLI::write('Fila processada: '.$enviados.' enviado(s), '.$falhas.' falha(s).');return $falhas?EXIT_ERROR:EXIT_SUCCESS;
 }
}
