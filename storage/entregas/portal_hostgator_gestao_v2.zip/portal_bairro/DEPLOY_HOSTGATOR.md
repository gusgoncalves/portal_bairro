# HostGator — Portal do Bairro em /portal/

## Publicação e atualização

URL pública: https://annecont.com.br/portal/. Código privado em /home1/anneco90/portal_bairro; somente o conteúdo de public em /home1/anneco90/public_html/portal. Preservar o index.php adaptado no servidor: ele deve carregar /home1/anneco90/portal_bairro/app/Config/Paths.php. Não sobrescrever o index.php remoto com o index local que usa ../app.

As atualizações são entregues em ZIP com duas pastas: portal_bairro (aplicação privada) e public_html/portal (arquivos públicos). Extrair na pasta /home1/anneco90, após backup. Enviar todos os arquivos do pacote juntos: a View depende de administracao.js para iniciar a interface. Não substituir o index.php remoto, .env, imagens, banco ou arquivos do sistema em /sistema. Não há migração SQL para as atualizações de interface e edição administrativa. Recarregar com Ctrl+F5.

Configuração:

```ini
CI_ENVIRONMENT = production
app.baseURL = 'https://annecont.com.br/portal/'
app.indexPage = ''
session.cookieName = portal_bairro_session
cookie.path = '/portal'
cookie.secure = true
# Opcional: vitrine mostrada ao entrar sem parâmetro. Usar o identificador real.
portal.defaultSlug = annecont
```

Sem identificador na URL, a aplicação usa o padrão acima se ativo, ou a primeira vitrine ativa. Não apresenta seletor público de outras vitrines. Cada vitrine tem seu link próprio, por exemplo https://annecont.com.br/portal/?portal=condominio#/. O master encontra Abrir vitrine na lista de portais; o gestor tem Abrir minha vitrine. Um gestor com vários vínculos continua com as permissões existentes, mas não há seletor público: utiliza os links de cada vitrine para definir o contexto.

O painel /portal/admin e as páginas de recuperação/definição de senha não dependem de uma vitrine. Com tabelas instaladas e zero vitrines, a página pública mostra Vitrine em preparação e mantém Entrar disponível. Se não há usuário master, inicialize via CLI, nunca por cadastro público automático:

```sh
cd /home1/anneco90/portal_bairro
/opt/cpanel/ea-php82/root/usr/bin/php spark portal:install --sem-portal
```

Confirmar que PHP 8.2 está disponível nesse caminho; se o site usa outra versão compatível, escolher o binário correspondente. O comando instala tabelas e cria o master inicial sem criar a Annecont. Em bases existentes não apaga dados nem redefine senhas; pode preservar/criar o acesso inicial conforme o instalador. Trocar a senha inicial imediatamente. Banco inexistente deve ser criado pelo cPanel; banco existente dispensa CREATE DATABASE no instalador. Preservar a pasta database completa, inclusive nomes_banco.json e mysql.sql.

## Remetente e SMTP

Criar uma caixa real, por exemplo portal@annecont.com.br, em cPanel > Contas de e-mail. Pode usar gustavo@annecont.com.br se preferir. Em Conectar dispositivos consultar o servidor SMTP e a conexão SSL/TLS recomendada. Não usar a senha do cPanel nem a do banco: usar a senha dessa caixa.

Para e-mail cPanel, HostGator recomenda o hostname do servidor. O endereço br464.hostgator.com.br foi visto no cPanel desta conta, mas deve ser confirmado em Conectar dispositivos: o e-mail pode estar em outro serviço. Se usa Titan, o servidor informado é smtp.titan.email. Não assumir que o servidor da caixa é o mesmo do site.

Adicionar ao .env privado, sem publicar credenciais no GitHub:

```ini
email.SMTPHost = 'HOST_SMTP_CONFIRMADO_NO_CPANEL'
email.SMTPUser = 'portal@annecont.com.br'
email.SMTPPass = 'SENHA_DA_CAIXA'
email.SMTPPort = 465
email.SMTPCrypto = ssl
email.fromEmail = 'portal@annecont.com.br'
email.fromName = 'Portal do Bairro'
# Manter portal.chaveEmails existente: não trocar a chave a cada deploy.
```

Alternativa caso o provedor indique STARTTLS: porta 587 e email.SMTPCrypto = tls. Não misturar porta 465 com STARTTLS. Conferir SPF e DKIM em Entregabilidade de e-mail no cPanel; se DNS é externo, aplicar os registros no provedor responsável. Testar entrega inclusive em Gmail e conferir spam.

## Teste e fila

Nenhuma mensagem real foi enviada pelo desenvolvedor nesta configuração. Em terminal com PHP compatível:

```sh
cd /home1/anneco90/portal_bairro
/opt/cpanel/ea-php82/root/usr/bin/php spark portal:email-teste gustavo@annecont.com.br
/opt/cpanel/ea-php82/root/usr/bin/php spark portal:emails
```

O primeiro comando enfileira; o segundo tenta enviar até 20 mensagens pendentes (não somente a de teste). O relatório informa envios aceitos pelo servidor SMTP e falhas; aceitação SMTP não garante caixa de entrada. Mensagens enviadas têm o corpo removido da fila. Falhas ficam registradas sem senha e têm novas tentativas, no máximo cinco. Não há tela de administração da fila nesta versão.

Sem Terminal: configurar Cron, provocar uma recuperação de senha para um usuário real de teste e aguardar a próxima execução. Não criar um endpoint público para processar e-mails.

## Cron

Em cPanel > Trabalhos Cron, usar intervalo permitido pelo plano. A documentação da HostGator indica mínimo de 15 minutos para hospedagem compartilhada. Configuração inicial: minuto */15, hora *, dia *, mês *, dia da semana *. Campo Comando:

```sh
cd /home1/anneco90/portal_bairro && /opt/cpanel/ea-php82/root/usr/bin/php spark portal:emails >> /home1/anneco90/portal_bairro/writable/logs/cron-emails.log 2>&1
```

Para testar pode aguardar esse intervalo ou executar manualmente no Terminal. Links de senha expiram em uma hora desde a geração; filas devem ser acompanhadas, pois a demora reduz esse prazo. Se volume ultrapassar a capacidade da fila, planejar maior capacidade/processamento antes de expansão.

O login inicial admin corresponde a admin@portal.local, que não é uma caixa real. Para testar recuperação do master, criar outro administrador com e-mail real e senha forte no painel; conferir o acesso antes de inativar o usuário inicial. Não trocar e-mail por SQL sem revisar os vínculos.

## Fluxos já conectados

- Novo anunciante criado pelo gestor: link individual de definição de senha.
- Novo gestor ou master criado pelo master: link de definição de senha.
- Esqueci minha senha: resposta genérica para proteger a existência da conta; link só para e-mail cadastrado em conta ativa.
- Gestor solicita redefinição para anunciante: link de definição de senha.
- Anunciante convida cliente a avaliar atendimento: link individual, de uso único, com a vitrine correta; cliente não precisa de login.
- Aprovar/rejeitar anúncio não gera notificação automática por e-mail nesta versão. Avaliação do atendimento pelo cliente é diferente da aprovação editorial pelo gestor.

Teste completo: cadastrar anunciante com seu e-mail de teste; processar fila; definir senha; pedir recuperação e validar link; publicar anúncio; enviar convite de avaliação; processar fila; avaliar uma vez e verificar recusa na reutilização. Conferir que todos os links começam com https://annecont.com.br/portal/ e que cada gestor só acessa os próprios vínculos.

Fontes: https://suporte.hostgator.com.br/hc/pt-br/articles/30811089087379 ; https://suporte.hostgator.com.br/hc/pt-br/articles/30812660878867 ; https://www.hostgator.com.br/blog/cron-job-guia-completo-para-automatizar-tarefas/

## Ajustes de administração e apresentação

Datas de período e vencimento são exibidas em dd/mm/aaaa; auditoria converte UTC armazenado para America/Sao_Paulo. Dados de banco e campos HTML date continuam em ISO. Pendente usa amarelo claro, vencido vermelho claro e pago verde claro, com rótulos além das cores.

Master edita nome/organização/endereço/capacidade/situação do portal preservando identificador público. Redução de capacidade respeita espaços ocupados. Gestores responsáveis aparecem na listagem de portais; responsáveis pelos anunciantes aparecem apenas nas respostas privadas e no painel do gestor, nunca na vitrine pública.

Master pode editar nome/e-mail/situação e opcionalmente senha de gestores ou outros administradores. Gestor altera e-mail apenas das contas anunciantes vinculadas à sua vitrine; uma conta compartilhada usa o mesmo e-mail em todos os vínculos. Minha conta exige senha atual para trocar o e-mail, mantém a sessão atual e invalida links anteriores de recuperação. E-mails duplicados são recusados. A troca de e-mail não inclui verificação por mensagem nesta versão.

O card Contatos gerados abre popup com um gráfico de pizza por anunciante, nome da empresa, totais, percentuais e legenda: verde WhatsApp, roxo Instagram. Sem cliques, o gráfico fica cinza e informa zero. O período é o mesmo do relatório, sem contar cliques como vendas. Os gráficos não dependem de bibliotecas externas.
